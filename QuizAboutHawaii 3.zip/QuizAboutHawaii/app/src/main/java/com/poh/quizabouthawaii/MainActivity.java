package com.poh.quizabouthawaii;

// The question asked in the app is based on an article form Hawaii Magazine
// 10 questions you were too embarrassed to ask about Hawaii ...

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    int score = 0;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void reset(View view){
        //Although the project assignement did not request reset option
        //This function was implemented allow muliple testing of this application

        name = " ";
        score = 0 ;

        // Reset name
        EditText editText = findViewById(R.id.name_edit_text);
        editText.getText().clear();

        //Reset question one checkbox
        CheckBox checkBox = findViewById(R.id.question_one_ans_a);
        if(checkBox.isChecked()) {
            checkBox.toggle();
        }
        checkBox = findViewById(R.id.question_one_ans_b);
        if(checkBox.isChecked()) {
            checkBox.toggle();
        }
        checkBox = findViewById(R.id.question_one_ans_c);
        if(checkBox.isChecked()) {
            checkBox.toggle();
        }
        checkBox = findViewById(R.id.question_one_ans_d);
        if(checkBox.isChecked()) {
            checkBox.toggle();
        }
        //Reset question two Radio group
        RadioGroup questionTwoGroup = findViewById(R.id.question_two);
        RadioButton rb2 = questionTwoGroup.findViewById(questionTwoGroup.getCheckedRadioButtonId());
        questionTwoGroup.clearCheck();

        //Reset question Three Radio group
        RadioGroup questionThreeGroup = findViewById(R.id.question_three);
        RadioButton rb3 = questionThreeGroup.findViewById(questionThreeGroup.getCheckedRadioButtonId());
        questionThreeGroup.clearCheck();

        //Reset question Four Radio group
        RadioGroup questionFourGroup = findViewById(R.id.question_four);
        RadioButton rb4 = questionFourGroup.findViewById(questionFourGroup.getCheckedRadioButtonId());
        questionFourGroup.clearCheck();

        //Reset question FiveRadio group
        RadioGroup questionFiveGroup = findViewById(R.id.question_five);
        RadioButton rb5 = questionFiveGroup.findViewById(questionFiveGroup.getCheckedRadioButtonId());
        questionFiveGroup.clearCheck();
    }

    public void submit(View view) {
        //Total score is 100 question. Each question is valued 20 points. The question one was implemented
        //with checkbox and allowed two valid answers (each answer is worth 10 points
        
        processName(view);
        processQuestionOne(view);
        processQuestionTwo(view);
        processQuestionThree(view);
        processQuestionFour(view);
        processQuestionFive(view);

        String temp = Integer.toString(score);
        Toast.makeText(MainActivity.this,  name + ", your score is " + temp, Toast.LENGTH_LONG).show();
    }

    //Attain name of the user
    public void processName(View view){
        EditText editText = findViewById(R.id.name_edit_text);
        name  = editText.getText().toString();
    }

    //Question one regarding why slippers are removed - ans 1.a or 1.b
    //To attain 20 points both 1.a and 1.b must be selected

    public void processQuestionOne (View view) {
        // ans  a & c are valid
        // and  d & e are invalid
        // Did not implement this function via onClick method
        // found an user may check and unckeck checkbox multiple time resulting inflated score


        CheckBox checkBox = findViewById(R.id.question_one_ans_a);
        if(checkBox.isChecked()) {
            score += 10;
        }
        checkBox = findViewById(R.id.question_one_ans_b);
        if(checkBox.isChecked()) {
           score += 10;
        }
    }

    //Question Two - who are hawaiian - valid Ans 2.b
    private void processQuestionTwo(View view){
        RadioGroup questionOneGroup = findViewById(R.id.question_two);
        RadioButton rb = questionOneGroup.findViewById(questionOneGroup.getCheckedRadioButtonId());
        if (rb != null) {
            boolean checked = rb.isChecked();
            if (checked) {
                if (rb.getId() == (R.id.question_two_ans_b)) {
                    score += 20;
                }
            }
        }
    }

    //Question three - why do Hawaii have interstate - valid Ans a
    private void processQuestionThree(View view){
        RadioGroup questionOneGroup = findViewById(R.id.question_three);
        RadioButton rb = questionOneGroup.findViewById(questionOneGroup.getCheckedRadioButtonId());
        if (rb != null) {
            boolean checked = rb.isChecked();
            if (checked) {
                if (rb.getId() == (R.id.question_three_ans_a)) {
                    score += 20;
                }
            }
        }
    }

    //Question four - Why do Hawaiian street have multiple vowels - valid Ans d
    private void processQuestionFour(View view){
        RadioGroup questionOneGroup = findViewById(R.id.question_four);
        RadioButton rb = questionOneGroup.findViewById(questionOneGroup.getCheckedRadioButtonId());
        if (rb != null) {
            boolean checked = rb.isChecked();
            if (checked) {
                if (rb.getId() == (R.id.question_four_ans_d)) {
                    score += 20;
                }
            }
        }
    }

    //Question five - Why such high cost of milk - valid Ans a
    private void processQuestionFive(View view){
        RadioGroup questionOneGroup = findViewById(R.id.question_five);
        RadioButton rb = questionOneGroup.findViewById(questionOneGroup.getCheckedRadioButtonId());
        if ( rb != null) {
            boolean checked = rb.isChecked();
            if (checked) {
                if (rb.getId() == (R.id.question_five_ans_a)) {
                    score += 20;
                }
            }
        }
    }

}